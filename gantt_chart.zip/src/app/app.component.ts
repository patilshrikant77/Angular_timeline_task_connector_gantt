import { Component, ViewChild, OnInit, AfterViewInit, ElementRef, HostListener } from '@angular/core';
import { SVGGantt, StrGantt,utils } from 'gantt';
import { DataService } from './utils/data.service';


@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss']
})

export class AppComponent implements  OnInit {
    svgGantt:any;
    strGantt:any;
    $:any;
    NS = 'http://www.w3.org/2000/svg';
    $svg = null;
    moving = false;
    $start = null;
    $line = null;
    tasks:any[];
    links:any[];

    constructor(private readonly dataService:DataService ){

    }
   

    ngOnInit(): void {

        this.$ = s => document.querySelector(s);
        const { tasks, links } = this.dataService.getData();

        const data = utils.formatData(tasks, links);
        this.tasks=tasks;
        this.links=links;

        const opts = {
            viewMode: 'week',
            onClick: v => console.log(v)
          };
          this.svgGantt = new SVGGantt('#svg', data, opts);
          this.strGantt = new StrGantt(data, opts);


        // onInit code.
        
          
        //   new SVGGantt('#svg-root', data, {
        //     viewMode: 'week'
        //   });
          
        //   new CanvasGantt('#canvas-root', data, {
        //     viewMode: 'week'
        //   });
          
        //   const strGantt = new StrGantt(data, {
        //     viewMode: 'week'
        //   });
          this.renderStr();
                 
    }
     renderStr() {
        this.dataService.formatXML(this.strGantt.render());
     }
      changeOptions(options) {
        this.svgGantt.setOptions(options);
        this.strGantt.setOptions(options);
        this.renderStr();
      }
      
       changeData() {
       
        const list = utils.formatData(this.tasks, this.links);
        this.svgGantt.setData(list);
        this.strGantt.setData(list);
        this.renderStr();
      }

       addLink(s, e) {
        
        const sid = parseInt(s.dataset['id']);
        const eid = parseInt(e.dataset['id']);
        const snode = this.tasks.find(t => t.id === sid);
        const enode = this.tasks.find(t => t.id === eid);
        let stype = this.isStart(s) ? 'S' : 'F';
        let etype = this.isStart(e) ? 'S' : 'F';
        if (snode.type === 'milestone') {
          stype = 'F';
        }
        if (enode.type === 'milestone') {
          etype = 'S';
        }
        this.links.push({ source: sid, target: eid, type: `${stype}${etype}` });
        this.changeData();
      }

       isStart(el) {
        return el.classList.contains('gantt-ctrl-start');
      }
      
       isFinish(el) {
        return el.classList.contains('gantt-ctrl-finish');
      }

      @HostListener('mousedown', ['$event'])
      onMousedown(e) {
            this.$svg = this.$('svg');
            if (!this.isStart(e.target) && !this.isFinish(e.target)) {
                return;
            }
            e.preventDefault();
            this.$start = e.target;
            document.querySelectorAll('.gantt-ctrl-start,.gantt-ctrl-finish').forEach((elem:HTMLElement)=> {
                elem.style['display'] = 'block';
            });
            this.moving = true;
            this.$line = document.createElementNS(this.NS, 'line');
            const x = this.$start.getAttribute('cx');
            const y = this.$start.getAttribute('cy');
            this.$line.setAttribute('x1', x);
            this.$line.setAttribute('y1', y);
            this.$line.setAttribute('x2', x);
            this.$line.setAttribute('y2', y);
            this.$line.style['stroke'] = '#ffa011';
            this.$line.style['stroke-width'] = '2';
            this.$line.style['stroke-dasharray'] = '5';
            this.$svg.appendChild(this.$line);
     }

     @HostListener('mousemove', ['$event'])
      onMousemove = (e) => {
        this.$svg = this.$('svg');
        if (!this.moving) return;
        e.preventDefault();
        if (this.isStart(e.target) || this.isFinish(e.target)) {
          const x = e.target.getAttribute('cx');
          const y = e.target.getAttribute('cy');
          this.$line.setAttribute('x2', x);
          this.$line.setAttribute('y2', y);
        } else {
          const x = e.clientX;
          const y = e.clientY;
          const rect = this.$svg.getBoundingClientRect();
          this.$line.setAttribute('x2', x - rect.left);
          this.$line.setAttribute('y2', y - rect.top);
        }
      };
      
      @HostListener('mouseup', ['$event'])
      onMouseup = (e) => {
        this.$svg = this.$('svg');
        if (!this.moving) return;
        e.preventDefault();
        const isCtrl = this.isStart(e.target) || this.isFinish(e.target);
        if (this.$start && isCtrl) {
          this.addLink(this.$start, e.target);
        }
      
        document.querySelectorAll('.gantt-ctrl-start,.gantt-ctrl-finish').forEach((elem:HTMLElement)=> {
          elem.style['display'] = 'none';
        });
        this.moving = false;
        if (this.$start) {
          this.$start.style['display'] = 'none';
          this.$start = null;
        }
        if (this.$line) {
          this.$svg.removeChild(this.$line);
          this.$line = null;
        }
      };
      

   
}